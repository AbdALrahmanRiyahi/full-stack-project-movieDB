const mongoose = require("mongoose");

const MovieSchema = new mongoose.Schema({
  movieId: { type: Number, required: true, unique: true },
  title: { type: String, required: true },
  description: String,
  releaseDate: Date,
  language: String,
  genre: [String],  // <-- Fixed here
  rating: Number,
  posterImageURL: String,
  castMembers: [String],
  favorite: { type: Boolean, default: false },
  directorId: Number
});

module.exports = mongoose.model("Movie", MovieSchema);
