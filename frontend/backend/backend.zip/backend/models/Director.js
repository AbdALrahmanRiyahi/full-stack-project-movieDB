const mongoose = require("mongoose")

const DirectorSchema = new mongoose.Schema({
  directorId: { type: Number, required: true, unique: true },
  name: { type: String, required: true },
  portraitURL: String,
  birthDate: Date,
  birthPlace: String,
  shortBio: String,
  fullBio: String,
  favorite: { type: Boolean, default: false }
})

module.exports = mongoose.model("Director", DirectorSchema)
