const express = require("express");
const router = express.Router();
const Movie = require("../models/Movie");
const verifyToken = require("../middleware/verifyToken");

// Create Movie (Protected)
router.post("/", verifyToken, async (req, res) => {
  try {
    const movie = new Movie(req.body);
    await movie.save();
    res.status(201).json(movie);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

// Get All Movies (Protected)
router.get("/", verifyToken, async (req, res) => {
  try {
    const movies = await Movie.find();
    res.json(movies);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Get Movie by movieId (Protected)
router.get("/:movieId", verifyToken, async (req, res) => {
  try {
    const movie = await Movie.findOne({ movieId: req.params.movieId });
    if (!movie) {
      return res.status(404).json({ message: "Movie not found" });
    }
    res.json(movie);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Update Movie by movieId (Protected)
router.put("/:movieId", verifyToken, async (req, res) => {
  try {
    const movie = await Movie.findOneAndUpdate(
      { movieId: req.params.movieId },
      req.body,
      { new: true }
    );

    if (!movie) {
      return res.status(404).json({ message: "Movie not found" });
    }

    res.json(movie);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Delete Movie by movieId (Protected)
router.delete("/:movieId", verifyToken, async (req, res) => {
  try {
    const movie = await Movie.findOneAndDelete({ movieId: req.params.movieId });
    if (!movie) {
      return res.status(404).json({ message: "Movie not found" });
    }
    res.json({ message: "Movie deleted successfully" });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;
