const express = require("express");
const router = express.Router();
const Director = require("../models/Director");
const verifyToken = require("../middleware/verifyToken");

// ✅ All routes below are protected by verifyToken

// Create Director (Protected)
router.post("/", verifyToken, async (req, res) => {
  try {
    const director = new Director(req.body);
    await director.save();
    res.status(201).json(director);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

// Get All Directors (Protected)
router.get("/", verifyToken, async (req, res) => {
  try {
    const directors = await Director.find();
    res.json(directors);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Get Single Director by directorId (Protected)
router.get("/:directorId", verifyToken, async (req, res) => {
  try {
    const director = await Director.findOne({ directorId: req.params.directorId });
    if (!director) {
      return res.status(404).json({ message: "Director not found" });
    }
    res.json(director);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Update Director by directorId (Protected)
router.put("/:directorId", verifyToken, async (req, res) => {
  try {
    const director = await Director.findOneAndUpdate(
      { directorId: req.params.directorId },
      req.body,
      { new: true }
    );
    if (!director) {
      return res.status(404).json({ message: "Director not found" });
    }
    res.json(director);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Delete Director by directorId (Protected)
router.delete("/:directorId", verifyToken, async (req, res) => {
  try {
    const director = await Director.findOneAndDelete({ directorId: req.params.directorId });
    if (!director) {
      return res.status(404).json({ message: "Director not found" });
    }
    res.json({ message: "Director deleted" });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;
